
import { useState, useEffect, useCallback } from "react";
import { Website } from "@/types/types";
import { supabase } from "@/lib/supabase";
import { toast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from "@tanstack/react-query";

const CACHE_TIME = 1000 * 60 * 60 * 24; // 24 hours
const STALE_TIME = 1000 * 60 * 60 * 24; // 24 hours

export const useWebsites = (selectedCategory: string | null) => {
  const queryClient = useQueryClient();

  const fetchWebsites = useCallback(async () => {
    try {
      let query = supabase
        .from("websites")
        .select(`
          id,
          title,
          description,
          url,
          image_url,
          category_id,
          created_at,
          position,
          category,
          verified,
          categories (
            id,
            name
          )
        `);

      if (selectedCategory) {
        const { data: categoryData } = await supabase
          .from('categories')
          .select('id')
          .eq('name', selectedCategory.toLowerCase())
          .maybeSingle();

        if (categoryData) {
          query = query.eq('category_id', categoryData.id);
        }
      }

      query = query.order('position', { ascending: true });

      const { data, error } = await query;

      if (error) throw error;

      return data?.map(website => ({
        ...website,
        categories: Array.isArray(website.categories) 
          ? website.categories[0] 
          : website.categories
      })) || [];
    } catch (error) {
      console.error("Error fetching websites:", error);
      toast({
        title: "Error loading websites",
        description: "Failed to load websites. Please try again.",
        variant: "destructive",
      });
      return [];
    }
  }, [selectedCategory]);

  const { data: websites = [], isLoading: loading } = useQuery({
    queryKey: ['websites'],
    queryFn: fetchWebsites,
    staleTime: STALE_TIME,
    gcTime: CACHE_TIME,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  // Filter websites by category after fetching if needed
  const filteredWebsites = selectedCategory
    ? websites.filter(website => 
        website.categories?.name?.toLowerCase() === selectedCategory.toLowerCase()
      )
    : websites;

  const updateWebsitePosition = useCallback(async (websiteId: string, newPosition: number) => {
    try {
      const { error } = await supabase
        .from("websites")
        .update({ position: newPosition })
        .eq("id", websiteId);

      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['websites'] });
    } catch (error) {
      console.error("Error updating website position:", error);
      toast({
        title: "Error updating position",
        description: "Failed to update website position. Please try again.",
        variant: "destructive",
      });
    }
  }, [queryClient]);

  return {
    websites: filteredWebsites,
    loading,
    updateWebsitePosition
  };
};
