
import { useState, useEffect } from "react";
import { Category } from "@/types/types";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export const useCategories = (isAdmin: boolean) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const { toast } = useToast();

  const fetchCategories = async () => {
    try {
      const { data } = await supabase
        .from("categories")
        .select("*")
        .order('position', { ascending: true })
        .order('created_at', { ascending: false });
      if (data) setCategories(data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const handleAddCategory = async (name: string) => {
    if (!isAdmin) return;

    // Get the highest position
    const maxPosition = Math.max(...categories.map(c => c.position || 0), 0);

    const { data, error } = await supabase
      .from("categories")
      .insert([{ name, position: maxPosition + 1 }])
      .select()
      .single();

    if (error) {
      toast({
        title: "Error adding category",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    if (data) {
      setCategories([...categories, data]);
      toast({
        title: "Success",
        description: "Category added successfully",
      });
    }
  };

  const handleUpdateCategory = async (id: string, name: string) => {
    if (!isAdmin) return;

    const { error } = await supabase
      .from("categories")
      .update({ name })
      .eq("id", id);

    if (error) {
      toast({
        title: "Error updating category",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    setCategories(categories.map(cat => 
      cat.id === id ? { ...cat, name } : cat
    ));
    toast({
      title: "Success",
      description: "Category updated successfully",
    });
  };

  const handleDeleteCategory = async (id: string) => {
    if (!isAdmin) return;

    const { error } = await supabase
      .from("categories")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "Error deleting category",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    setCategories(categories.filter(cat => cat.id !== id));
    toast({
      title: "Success",
      description: "Category deleted successfully",
    });
  };

  const updateCategoryPosition = async (categoryId: string, newPosition: number) => {
    if (!isAdmin) return;

    try {
      const { error } = await supabase
        .from("categories")
        .update({ position: newPosition })
        .eq("id", categoryId);

      if (error) throw error;

      // Update local state
      setCategories(prev => {
        const updatedCategories = [...prev];
        const categoryIndex = updatedCategories.findIndex(c => c.id === categoryId);
        if (categoryIndex !== -1) {
          updatedCategories[categoryIndex] = {
            ...updatedCategories[categoryIndex],
            position: newPosition
          };
        }
        return updatedCategories.sort((a, b) => (a.position || 0) - (b.position || 0));
      });

      toast({
        title: "Success",
        description: "Category position updated successfully",
      });
    } catch (error) {
      console.error("Error updating category position:", error);
      toast({
        title: "Error updating position",
        description: "Failed to update category position",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return {
    categories,
    handleAddCategory,
    handleUpdateCategory,
    handleDeleteCategory,
    updateCategoryPosition,
  };
};
