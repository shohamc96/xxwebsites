
import { useState, useEffect } from "react";
import { Website } from "@/types/types";

interface WebsiteFormData {
  title: string;
  description: string;
  url: string;
  image_url: string;
  category_id: string;
  position: number;
  verified: boolean;
}

export const useWebsiteForm = (editingWebsite: Website | null) => {
  const [formData, setFormData] = useState<WebsiteFormData>({
    title: "",
    description: "",
    url: "",
    image_url: "",
    category_id: "",
    position: 0,
    verified: false,
  });

  useEffect(() => {
    if (editingWebsite) {
      setFormData({
        title: editingWebsite.title,
        description: editingWebsite.description,
        url: editingWebsite.url,
        image_url: editingWebsite.image_url,
        category_id: editingWebsite.category_id,
        position: editingWebsite.position || 0,
        verified: editingWebsite.verified || false,
      });
    } else {
      setFormData({
        title: "",
        description: "",
        url: "",
        image_url: "",
        category_id: "",
        position: 0,
        verified: false,
      });
    }
  }, [editingWebsite]);

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      url: "",
      image_url: "",
      category_id: "",
      position: 0,
      verified: false,
    });
  };

  return { formData, setFormData, resetForm };
};
