
export interface Website {
  id: string;
  title: string;
  description: string;
  url: string;
  image_url: string;
  category_id: string;
  created_at: string;
  position: number;
  category: string | null;
  verified?: boolean;
  categories?: {
    id: string;
    name: string;
  };
}

export interface Category {
  id: string;
  name: string;
  created_at: string;
  position: number;
}

