
import { Website } from "@/types/types";
import { WebsiteCard } from "@/components/WebsiteCard";
import { useAuth } from "@/contexts/AuthContext";
import { useState, useMemo } from "react";
import { toast } from "@/hooks/use-toast";

interface WebsiteGridProps {
  websites: Website[];
  loading: boolean;
  onUpdateWebsite: (websiteId: string, data: Partial<Website>) => Promise<void>;
  onUpdatePosition: (websiteId: string, newPosition: number) => Promise<void>;
}

export const WebsiteGrid = ({
  websites,
  loading,
  onUpdateWebsite,
  onUpdatePosition
}: WebsiteGridProps) => {
  const { isAdmin } = useAuth();
  const [draggedWebsite, setDraggedWebsite] = useState<Website | null>(null);

  const handleDragStart = (website: Website) => (e: React.DragEvent) => {
    if (!isAdmin) return;
    setDraggedWebsite(website);
    e.dataTransfer.setData('text/plain', website.id);
    const draggableElement = e.target as HTMLElement;
    draggableElement.classList.add('opacity-50');
  };

  const handleDragEnd = (e: React.DragEvent) => {
    const draggableElement = e.target as HTMLElement;
    draggableElement.classList.remove('opacity-50');
    setDraggedWebsite(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    if (!isAdmin) return;
    e.preventDefault();
  };

  const handleDrop = (targetWebsite: Website) => async (e: React.DragEvent) => {
    if (!isAdmin || !draggedWebsite) return;
    e.preventDefault();

    if (draggedWebsite.id !== targetWebsite.id) {
      const draggedPosition = draggedWebsite.position || 0;
      const targetPosition = targetWebsite.position || 0;

      await onUpdatePosition(draggedWebsite.id, targetPosition);

      const affectedWebsites = websites.filter(w => {
        const pos = w.position || 0;
        return draggedPosition < targetPosition 
          ? pos > draggedPosition && pos <= targetPosition 
          : pos < draggedPosition && pos >= targetPosition;
      });

      for (const website of affectedWebsites) {
        const newPosition = draggedPosition < targetPosition 
          ? (website.position || 0) - 1 
          : (website.position || 0) + 1;
        await onUpdatePosition(website.id, newPosition);
      }

      toast({
        title: "Success",
        description: "Website position updated successfully"
      });
    }
    setDraggedWebsite(null);
  };

  // Memoize grouped websites to prevent unnecessary recalculations
  const { groupedWebsites, sortedCategories } = useMemo(() => {
    const categoryOrder = ['top 10', 'live cam', 'vr', 'ai', 'arab', 'social', 'japanese', 'taboo', 'onlygirls', 'gay'];
    
    const grouped = websites.reduce((acc, website) => {
      const categoryName = website.categories?.name || 'Other';
      if (!acc[categoryName]) {
        acc[categoryName] = [];
      }
      acc[categoryName].push(website);
      return acc;
    }, {} as Record<string, Website[]>);

    // Sort websites within each category by position
    Object.keys(grouped).forEach(category => {
      grouped[category].sort((a, b) => (a.position || 0) - (b.position || 0));
    });

    const sorted = Object.keys(grouped).sort((a, b) => {
      const indexA = categoryOrder.indexOf(a.toLowerCase());
      const indexB = categoryOrder.indexOf(b.toLowerCase());
      if (indexA !== -1 && indexB !== -1) return indexA - indexB;
      if (indexA !== -1) return -1;
      if (indexB !== -1) return 1;
      return a.localeCompare(b);
    });

    return { groupedWebsites: grouped, sortedCategories: sorted };
  }, [websites]);

  const getCategoryTitle = (category: string) => {
    if (category.toLowerCase() === 'vr') return 'VR Websites';
    if (category.toLowerCase() === 'ai') return 'AI Websites';
    return `${category.charAt(0).toUpperCase() + category.slice(1)} Websites`;
  };

  if (loading && websites.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {sortedCategories.map(category => (
        <div key={category} className="space-y-4">
          <h2 className="font-extrabold text-2xl px-0 py-0 text-left">
            {getCategoryTitle(category)}
          </h2>
          <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {groupedWebsites[category].map((website) => (
              <article 
                key={website.id}
                className="transition-all duration-200"
              >
                <WebsiteCard
                  website={website}
                  onUpdate={onUpdateWebsite}
                  draggable={isAdmin}
                  onDragStart={handleDragStart(website)}
                  onDragEnd={handleDragEnd}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop(website)}
                />
              </article>
            ))}
          </section>
        </div>
      ))}
    </div>
  );
};
