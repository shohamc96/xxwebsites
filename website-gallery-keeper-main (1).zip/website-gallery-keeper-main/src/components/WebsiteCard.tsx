
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Website } from '@/types/types';
import { Link } from "react-router-dom";
import { EditWebsiteDialog } from "./EditWebsiteDialog";
import { useAuth } from "@/contexts/AuthContext";
import { BadgeCheck } from "lucide-react";
import { useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface WebsiteCardProps {
  website: Website;
  onUpdate: (websiteId: string, data: Partial<Website>) => Promise<void>;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent) => void;
  onDragEnd?: (e: React.DragEvent) => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
}

export const WebsiteCard = ({
  website,
  onUpdate,
  draggable,
  onDragStart,
  onDragEnd,
  onDragOver,
  onDrop
}: WebsiteCardProps) => {
  const { isAdmin } = useAuth();
  const [imageLoaded, setImageLoaded] = useState(false);
  const isMobile = useIsMobile();

  // Generate smaller image URL for mobile devices if possible
  const getMobileImageUrl = (url: string) => {
    // If the URL already contains size parameters, try to reduce them
    // This is a simplified example - adapt based on your actual image URLs
    if (url.includes('?')) {
      return url.replace(/width=\d+/g, 'width=300').replace(/height=\d+/g, 'height=150');
    }
    return url;
  };

  return (
    <div 
      draggable={draggable} 
      onDragStart={onDragStart} 
      onDragEnd={onDragEnd} 
      onDragOver={onDragOver} 
      onDrop={onDrop} 
      className="relative"
    >
      <Link 
        to={`/websites/${website.id}`} 
        aria-label={`View details for ${website.title}`}
        className="block"
      >
        <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg cursor-pointer h-full">
          <CardHeader className="p-3">
            <div className="aspect-[2/1] relative bg-gray-100">
              {!imageLoaded && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              )}
              <img
                src={isMobile ? getMobileImageUrl(website.image_url) : website.image_url}
                srcSet={`${getMobileImageUrl(website.image_url)} 300w, ${website.image_url} 800w`}
                sizes="(max-width: 768px) 300px, 800px"
                alt={`Screenshot of ${website.title}`}
                className={`w-full h-full object-contain transition-opacity duration-300 ${
                  imageLoaded ? 'opacity-100' : 'opacity-0'
                }`}
                loading="lazy"
                decoding="async"
                onLoad={() => setImageLoaded(true)}
                width={isMobile ? 300 : 400}
                height={isMobile ? 150 : 200}
              />
            </div>
          </CardHeader>
          <CardContent className="p-2 text-center border-t">
            <div className="flex items-center justify-center gap-1">
              <h2 className="font-semibold text-base line-clamp-1">{website.title}</h2>
              {website.verified && (
                <BadgeCheck className="h-5 w-5 text-[#c80613] bg-[#c80613]/10 rounded-full flex-shrink-0" />
              )}
            </div>
          </CardContent>
        </Card>
      </Link>
      {isAdmin && <EditWebsiteDialog website={website} onUpdate={onUpdate} />}
    </div>
  );
};
