import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Category, Website } from "@/types/types";
import { Plus } from "lucide-react";
import { WebsiteForm } from "./WebsiteForm";
import { WebsiteList } from "./WebsiteList";
import { useWebsiteForm } from "@/hooks/useWebsiteForm";
interface AddWebsiteDialogProps {
  categories: Category[];
  websites: Website[];
  onAddWebsite: (website: {
    title: string;
    description: string;
    url: string;
    image_url: string;
    category_id: string;
    position: number;
  }) => void;
  onUpdateWebsite: (id: string, website: {
    title: string;
    description: string;
    url: string;
    image_url: string;
    category_id: string;
    position: number;
  }) => void;
  onDeleteWebsite: (id: string) => void;
  isAdmin: boolean;
}
export const AddWebsiteDialog = ({
  categories,
  websites,
  onAddWebsite,
  onUpdateWebsite,
  onDeleteWebsite,
  isAdmin
}: AddWebsiteDialogProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [editingWebsite, setEditingWebsite] = useState<Website | null>(null);
  const {
    formData,
    setFormData,
    resetForm
  } = useWebsiteForm(editingWebsite);
  if (!isAdmin) return null;
  const handleFormChange = (field: string, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingWebsite) {
      onUpdateWebsite(editingWebsite.id, formData);
    } else {
      onAddWebsite(formData);
    }
    resetForm();
    setEditingWebsite(null);
    setIsOpen(false);
  };
  const handleDelete = (website: Website) => {
    if (window.confirm(`Are you sure you want to delete ${website.title}?`)) {
      onDeleteWebsite(website.id);
    }
  };
  return <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Manage Websites
        </Button>
      </DialogTrigger>
      <DialogContent className="">
        <DialogHeader>
          <DialogTitle>{editingWebsite ? 'Edit Website' : 'Add New Website'}</DialogTitle>
        </DialogHeader>
        <WebsiteForm formData={formData} onFormChange={handleFormChange} categories={categories} isEditing={!!editingWebsite} onSubmit={handleSubmit} />
        <WebsiteList websites={websites} onEdit={setEditingWebsite} onDelete={handleDelete} />
      </DialogContent>
    </Dialog>;
};