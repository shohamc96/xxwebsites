
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Category } from "@/types/types";

interface AddCategoryDialogProps {
  onAddCategory: (name: string) => void;
  onUpdateCategory: (id: string, name: string) => void;
  onDeleteCategory: (id: string) => void;
  categories: Category[];
  isAdmin: boolean;
}

export const AddCategoryDialog = ({ 
  onAddCategory, 
  onUpdateCategory, 
  onDeleteCategory,
  categories,
  isAdmin 
}: AddCategoryDialogProps) => {
  const [name, setName] = useState("");
  const [position, setPosition] = useState<number>(0);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (editingCategory) {
      setName(editingCategory.name);
      setPosition(editingCategory.position);
    } else {
      setName("");
      setPosition(categories.length + 1);
    }
  }, [editingCategory, categories.length]);

  if (!isAdmin) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCategory) {
      onUpdateCategory(editingCategory.id, name);
    } else {
      onAddCategory(name);
    }
    setName("");
    setPosition(0);
    setEditingCategory(null);
    setIsOpen(false);
  };

  const handleDelete = (category: Category) => {
    if (window.confirm(`Are you sure you want to delete ${category.name}?`)) {
      onDeleteCategory(category.id);
    }
  };

  const handleCancel = () => {
    setName("");
    setPosition(0);
    setEditingCategory(null);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Manage Categories
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{editingCategory ? 'Edit Category' : 'Add New Category'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Category Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter category name"
              required
            />
          </div>
          <div>
            <Label htmlFor="position">Position</Label>
            <Input
              id="position"
              type="number"
              min={1}
              value={position}
              onChange={(e) => setPosition(parseInt(e.target.value))}
              placeholder="Enter position number"
              required
            />
          </div>
          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {editingCategory ? 'Update Category' : 'Add Category'}
            </Button>
            {editingCategory && (
              <Button type="button" variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
            )}
          </div>
        </form>
        {categories.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2">Existing Categories</h3>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center justify-between p-2 bg-secondary rounded-md">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">#{category.position}</span>
                    <span>{category.name}</span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingCategory(category);
                        setName(category.name);
                        setPosition(category.position);
                      }}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(category)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
