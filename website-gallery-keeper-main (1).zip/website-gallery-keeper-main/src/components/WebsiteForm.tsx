
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Category } from "@/types/types";

interface WebsiteFormProps {
  formData: {
    title: string;
    description: string;
    url: string;
    image_url: string;
    category_id: string;
    position: number;
    verified: boolean;
  };
  onFormChange: (field: string, value: string | number | boolean) => void;
  categories: Category[];
  isEditing: boolean;
  onSubmit: (e: React.FormEvent) => void;
}

export const WebsiteForm = ({ formData, onFormChange, categories, isEditing, onSubmit }: WebsiteFormProps) => {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => onFormChange('title', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="description">Description</Label>
        <Input
          id="description"
          value={formData.description}
          onChange={(e) => onFormChange('description', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="url">URL</Label>
        <Input
          id="url"
          type="url"
          value={formData.url}
          onChange={(e) => onFormChange('url', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input
          id="imageUrl"
          value={formData.image_url}
          onChange={(e) => onFormChange('image_url', e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="position">Position (1 is top)</Label>
        <Input
          id="position"
          type="number"
          min="0"
          value={formData.position}
          onChange={(e) => onFormChange('position', parseInt(e.target.value) || 0)}
          required
        />
      </div>
      <div>
        <Label>Category</Label>
        <Select
          value={formData.category_id}
          onValueChange={(value) => onFormChange('category_id', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center space-x-2">
        <Switch
          id="verified"
          checked={formData.verified}
          onCheckedChange={(checked) => onFormChange('verified', checked)}
        />
        <Label htmlFor="verified">Verified Website</Label>
      </div>
      <Button type="submit" className="w-full bg-[#c80613] hover:bg-[#c80613]/90">
        {isEditing ? 'Update Website' : 'Add Website'}
      </Button>
    </form>
  );
};
