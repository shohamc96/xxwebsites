import { AddWebsiteDialog } from "@/components/AddWebsiteDialog";
import { AddCategoryDialog } from "@/components/AddCategoryDialog";
import { Website, Category } from "@/types/types";
interface HeaderProps {
  categories: Category[];
  websites: Website[];
  isAdmin: boolean;
  onAddCategory: (name: string) => Promise<void>;
  onUpdateCategory: (id: string, name: string) => Promise<void>;
  onDeleteCategory: (id: string) => Promise<void>;
  onAddWebsite: (website: Omit<Website, "id" | "created_at">) => Promise<void>;
  onUpdateWebsite: (id: string, website: Omit<Website, "id" | "created_at">) => Promise<void>;
  onDeleteWebsite: (id: string) => Promise<void>;
}
export const Header = ({
  categories,
  websites,
  isAdmin,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onAddWebsite,
  onUpdateWebsite,
  onDeleteWebsite
}: HeaderProps) => {
  return <header className="flex flex-col items-center justify-center text-center mb-8">
      <div className="space-y-2">
        <h1 className="text-gray-950 text-4xl font-extrabold text-left">xxWebsites</h1>
      </div>
      {isAdmin && <div className="flex gap-2 mt-4">
          <AddCategoryDialog onAddCategory={onAddCategory} onUpdateCategory={onUpdateCategory} onDeleteCategory={onDeleteCategory} categories={categories} isAdmin={isAdmin} />
          <AddWebsiteDialog categories={categories} websites={websites} onAddWebsite={onAddWebsite} onUpdateWebsite={onUpdateWebsite} onDeleteWebsite={onDeleteWebsite} isAdmin={isAdmin} />
        </div>}
    </header>;
};