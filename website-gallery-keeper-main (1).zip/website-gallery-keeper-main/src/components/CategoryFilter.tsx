import { Button } from "@/components/ui/button";
import { Category } from "@/types/types";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRef, useState, useMemo, useCallback } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
interface CategoryFilterProps {
  categories: Category[];
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
}
export const CategoryFilter = ({
  categories,
  selectedCategory,
  onSelectCategory
}: CategoryFilterProps) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const isMobile = useIsMobile();
  const handleScroll = useCallback(() => {
    if (scrollContainerRef.current) {
      const {
        scrollLeft,
        scrollWidth,
        clientWidth
      } = scrollContainerRef.current;
      setShowLeftArrow(scrollLeft > 0);
      setShowRightArrow(scrollLeft + clientWidth < scrollWidth);
    }
  }, []);
  const scroll = useCallback((direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 200;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  }, []);
  const menuItems = useMemo(() => [{
    name: null,
    displayName: "All"
  }, ...categories.map(cat => ({
    name: cat.name,
    displayName: cat.name.charAt(0).toUpperCase() + cat.name.slice(1)
  }))], [categories]);
  const renderButton = useCallback((item: {
    name: string | null;
    displayName: string;
  }) => <Button key={item.name || 'all'} variant={selectedCategory === item.name ? "default" : "outline"} onClick={() => onSelectCategory(item.name)} className={`${selectedCategory === item.name ? "bg-[#af181f] hover:bg-[#af181f]/90 text-white" : "hover:bg-[#af181f]/10"} whitespace-nowrap flex-shrink-0 text-sm`} size="sm">
      {item.displayName}
    </Button>, [selectedCategory, onSelectCategory]);
  return <div className="relative w-full">
      {!isMobile && showLeftArrow && <button onClick={() => scroll('left')} className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 p-2 rounded-full shadow-md hover:bg-white">
          <ChevronLeft className="h-4 w-4" />
        </button>}
      
      <div ref={scrollContainerRef} onScroll={handleScroll} className="flex overflow-x-auto gap-2 scrollbar-hide py-[8px] md:px-0 px-0">
        {menuItems.map(renderButton)}
      </div>

      {!isMobile && showRightArrow && <button onClick={() => scroll('right')} className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 p-2 rounded-full shadow-md hover:bg-white">
          <ChevronRight className="h-4 w-4" />
        </button>}
    </div>;
};