
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export const Footer = () => {
  const footerLinks = [
    { title: "Disclaimer", path: "/disclaimer" },
    { title: "2257", path: "/2257" },
    { title: "DMCA", path: "/dmca" },
    { title: "Privacy Policy", path: "/privacy-policy" },
    { title: "Terms of Service", path: "/terms-of-service" },
    { title: "RTA", path: "/rta" },
  ];

  return (
    <footer className="border-t mt-8">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <nav className="grid gap-2">
          {footerLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="flex items-center justify-between p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <span className="text-gray-700">{link.title}</span>
              <ArrowRight className="h-4 w-4 text-gray-400" />
            </Link>
          ))}
        </nav>
      </div>
    </footer>
  );
};
