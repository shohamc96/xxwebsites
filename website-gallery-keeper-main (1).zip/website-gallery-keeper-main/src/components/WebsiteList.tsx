
import { Button } from "@/components/ui/button";
import { Website } from "@/types/types";
import { Pencil, Trash2 } from "lucide-react";

interface WebsiteListProps {
  websites: Website[];
  onEdit: (website: Website) => void;
  onDelete: (website: Website) => void;
}

export const WebsiteList = ({ websites, onEdit, onDelete }: WebsiteListProps) => {
  if (websites.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="text-sm font-medium mb-2">Existing Websites</h3>
      <div className="space-y-2 max-h-[300px] overflow-y-auto">
        {websites.map((website) => (
          <div key={website.id} className="flex items-center justify-between p-2 bg-secondary rounded-md">
            <span className="flex items-center gap-2">
              <span className="bg-primary text-white px-2 py-1 rounded text-sm">
                {website.position || 0}
              </span>
              {website.title}
            </span>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onEdit(website)}
              >
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDelete(website)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
