
import { Website, Category } from '@/types/types';

export const mockCategories: Category[] = [
  { 
    id: '1', 
    name: 'Technology',
    created_at: new Date().toISOString(),
    position: 1
  },
  { 
    id: '2', 
    name: 'Design',
    created_at: new Date().toISOString(),
    position: 2
  },
  { 
    id: '3', 
    name: 'Education',
    created_at: new Date().toISOString(),
    position: 3
  },
  { 
    id: '4', 
    name: 'Productivity',
    created_at: new Date().toISOString(),
    position: 4
  },
];

export const mockWebsites: Website[] = [
  {
    id: '1',
    title: 'Design Resources Hub',
    description: 'A curated collection of design tools and resources for creatives.',
    url: 'https://example.com',
    image_url: '/placeholder.svg',
    category_id: '2',
    created_at: new Date().toISOString(),
    position: 0,
    category: 'Design'
  },
  {
    id: '2',
    title: 'Tech News Daily',
    description: 'Stay updated with the latest in technology and innovation.',
    url: 'https://example.com',
    image_url: '/placeholder.svg',
    category_id: '1',
    created_at: new Date().toISOString(),
    position: 1,
    category: 'Technology'
  },
];

