
import { useCallback, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Helmet } from "react-helmet";
import { CategoryFilter } from "@/components/CategoryFilter";
import { Header } from "@/components/Header";
import { WebsiteGrid } from "@/components/WebsiteGrid";
import { useWebsites } from "@/hooks/useWebsites";
import { useCategories } from "@/hooks/useCategories";
import { Website } from "@/types/types";
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { toast } from "@/hooks/use-toast";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false
    }
  }
});

const IndexContent = () => {
  const { isAdmin } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const {
    websites,
    loading,
    updateWebsitePosition
  } = useWebsites(selectedCategory);
  const {
    categories,
    handleAddCategory,
    handleUpdateCategory,
    handleDeleteCategory
  } = useCategories(isAdmin);

  const handleAddWebsite = async (website: Omit<Website, "id" | "created_at">) => {
    if (!isAdmin) return;
    const { data, error } = await supabase
      .from("websites")
      .insert([website])
      .select()
      .single();

    if (error) {
      toast({
        title: "Error adding website",
        description: error.message,
        variant: "destructive"
      });
      return;
    }

    if (data) {
      toast({
        title: "Success",
        description: "Website added successfully"
      });
    }
  };

  const handleUpdateWebsite = async (id: string, websiteData: Omit<Website, "id" | "created_at">) => {
    if (!isAdmin) return;
    const { error } = await supabase
      .from("websites")
      .update(websiteData)
      .eq("id", id);

    if (error) {
      toast({
        title: "Error updating website",
        description: error.message,
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Success",
      description: "Website updated successfully"
    });
  };

  const handleDeleteWebsite = async (id: string) => {
    if (!isAdmin) return;
    const { error } = await supabase
      .from("websites")
      .delete()
      .eq("id", id);

    if (error) {
      toast({
        title: "Error deleting website",
        description: error.message,
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Success",
      description: "Website deleted successfully"
    });
  };

  return (
    <>
      <Helmet>
        <title>Website Gallery Keeper - Curated Collection of Inspiring Websites</title>
        <meta name="description" content="Discover and explore a carefully curated collection of inspiring websites across various categories." />
      </Helmet>

      <main className="mx-auto w-full">
        <div className="py-0 md:py-0">
          <Header 
            categories={categories}
            websites={websites}
            isAdmin={isAdmin}
            onAddCategory={handleAddCategory}
            onUpdateCategory={handleUpdateCategory}
            onDeleteCategory={handleDeleteCategory}
            onAddWebsite={handleAddWebsite}
            onUpdateWebsite={handleUpdateWebsite}
            onDeleteWebsite={handleDeleteWebsite}
          />
        </div>

        <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm shadow-sm">
          <CategoryFilter 
            categories={categories}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />
        </nav>

        <div className="md:px-4 py-4">
          <WebsiteGrid 
            websites={websites}
            loading={loading}
            onUpdateWebsite={handleUpdateWebsite}
            onUpdatePosition={updateWebsitePosition}
          />
        </div>
      </main>
    </>
  );
};

const Index = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <IndexContent />
    </QueryClientProvider>
  );
};

export default Index;
