
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const PrivacyPolicy = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      <div className="prose max-w-none">
        <p>We are committed to protecting your privacy. This Privacy Policy explains our data collection and processing practices.</p>
        <h2>Information Collection</h2>
        <p>We collect information that you provide directly to us, including when you create an account or contact us for support.</p>
        <h2>Use of Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
          <li>Provide and maintain our services</li>
          <li>Respond to your requests and inquiries</li>
          <li>Send you technical notices and updates</li>
          <li>Monitor and analyze trends and usage</li>
        </ul>
        <h2>Information Sharing</h2>
        <p>We do not sell or rent your personal information to third parties. We may share your information in the following situations:</p>
        <ul>
          <li>With your consent</li>
          <li>To comply with legal obligations</li>
          <li>To protect our rights and prevent fraud</li>
        </ul>
        <h2>Security</h2>
        <p>We take reasonable measures to protect your information from unauthorized access or disclosure.</p>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
