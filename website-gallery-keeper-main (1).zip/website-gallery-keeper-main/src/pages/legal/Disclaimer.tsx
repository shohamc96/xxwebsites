
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const Disclaimer = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">Disclaimer</h1>
      <div className="prose max-w-none">
        <p>This website contains links to third-party websites. We are not responsible for the content, accuracy, or opinions expressed on such websites, and such websites are not monitored, investigated, or checked for accuracy or completeness by us.</p>
        <p>Inclusion of any linked website does not imply or express our approval or endorsement of the linked website, or any material contained on that website.</p>
        <p>By accessing these third-party websites, you do so at your own risk.</p>
      </div>
    </div>
  );
};

export default Disclaimer;
