
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const TermsOfService = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      <div className="prose max-w-none">
        <p>By accessing this website, you agree to be bound by these Terms of Service.</p>
        <h2>Use License</h2>
        <p>Permission is granted to temporarily access the materials on our website for personal, non-commercial transitory viewing only.</p>
        <h2>Disclaimer</h2>
        <p>The materials on our website are provided on an 'as is' basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
        <h2>Limitations</h2>
        <p>In no event shall we or our suppliers be liable for any damages arising out of the use or inability to use the materials on our website.</p>
        <h2>Revisions</h2>
        <p>We may revise these terms of service at any time without notice. By using this website, you agree to be bound by the current version of these terms of service.</p>
      </div>
    </div>
  );
};

export default TermsOfService;
