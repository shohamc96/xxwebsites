
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const RTA = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">RTA Label</h1>
      <div className="prose max-w-none">
        <p>This website is labeled with the Restricted To Adults (RTA) website label to help parents block access using filtering software.</p>
        <p>The RTA label is a voluntary self-labeling system that helps prevent minors from accessing adult-oriented websites.</p>
        <p>For more information about the RTA label, please visit: <a href="http://www.rtalabel.org" target="_blank" rel="noopener noreferrer">www.rtalabel.org</a></p>
      </div>
    </div>
  );
};

export default RTA;
