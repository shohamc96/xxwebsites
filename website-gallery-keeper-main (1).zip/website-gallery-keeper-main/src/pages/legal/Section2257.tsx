
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const Section2257 = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">2257 Compliance Statement</h1>
      <div className="prose max-w-none">
        <p>This website is a directory of links to other websites. We do not create, produce, or host any content.</p>
        <p>All links and thumbnails that appear on this site are provided by third parties and are in compliance with USC 2257.</p>
        <p>For 2257 compliance information regarding the content on websites that we link to, please visit the respective websites directly.</p>
      </div>
    </div>
  );
};

export default Section2257;
