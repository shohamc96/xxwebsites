
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const DMCA = () => {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4">
      <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Directory
      </Link>
      
      <h1 className="text-3xl font-bold mb-6">DMCA Policy</h1>
      <div className="prose max-w-none">
        <p>We respect the intellectual property rights of others and expect our users to do the same. In accordance with the Digital Millennium Copyright Act of 1998, we will respond expeditiously to claims of copyright infringement that are reported to our designated copyright agent.</p>
        <h2>DMCA Notice</h2>
        <p>If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement and is accessible on this site, you may notify our copyright agent. For your complaint to be valid under the DMCA, you must provide the following information:</p>
        <ul>
          <li>A physical or electronic signature of a person authorized to act on behalf of the copyright owner</li>
          <li>Identification of the copyrighted work claimed to have been infringed</li>
          <li>Identification of the material that is claimed to be infringing or to be the subject of infringing activity</li>
          <li>Contact information for the claimant</li>
          <li>A statement that the claimant has a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or the law</li>
          <li>A statement that the information in the notification is accurate, and under penalty of perjury, that the complaining party is authorized to act on behalf of the owner of the copyright that is allegedly infringed</li>
        </ul>
      </div>
    </div>
  );
};

export default DMCA;
