
import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BadgeCheck } from "lucide-react";
import { Website } from '@/types/types';
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { Toggle } from "@/components/ui/toggle";
import { Bold, Italic, Underline as UnderlineIcon, Heading1, Heading2, List } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useIsMobile } from "@/hooks/use-mobile";

export const WebsiteDetails = () => {
  const {
    id
  } = useParams();
  const [website, setWebsite] = useState<Website | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const {
    isAdmin
  } = useAuth();
  const {
    toast
  } = useToast();
  const isMobile = useIsMobile();
  
  const editor = useEditor({
    extensions: [StarterKit, Underline],
    content: website?.description || "",
    editable: isAdmin,
    onUpdate: ({
      editor
    }) => {
      handleDescriptionUpdate(editor.getHTML());
    }
  });

  const handleDescriptionUpdate = async (newDescription: string) => {
    if (!website || !isAdmin) return;
    const {
      error
    } = await supabase.from("websites").update({
      description: newDescription
    }).eq("id", website.id);
    if (error) {
      toast({
        title: "Error updating description",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    const fetchWebsiteData = async () => {
      if (!id) return;
      const {
        data: websiteData
      } = await supabase.from("websites").select("*").eq("id", id).single();
      if (websiteData) {
        setWebsite(websiteData);
        editor?.commands.setContent(websiteData.description);
      }
      setIsLoading(false);
    };
    fetchWebsiteData();
  }, [id]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (!website) {
    return <div>Website not found</div>;
  }

  // Generate smaller image URL for mobile devices if possible
  const getMobileImageUrl = (url: string) => {
    // If the URL already contains size parameters, try to reduce them
    if (url.includes('?')) {
      return url.replace(/width=\d+/g, 'width=300').replace(/height=\d+/g, 'height=150');
    }
    return url;
  };

  return (
    <div className="max-w-7xl mx-auto py-8">
      <div className="px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80">
          <ArrowLeft className="h-4 w-4" />
          Back to Directory
        </Link>
      </div>
      
      <div className="grid md:grid-cols-3 gap-8 mt-6 px-4">
        <div className="md:col-span-1 space-y-6">
          <Card className="overflow-hidden shadow-lg">
            <div className="p-4">
              <div className="aspect-[2/1] relative rounded-lg overflow-hidden">
                <img
                  src={isMobile ? getMobileImageUrl(website.image_url) : website.image_url}
                  srcSet={`${getMobileImageUrl(website.image_url)} 300w, ${website.image_url} 800w`}
                  sizes="(max-width: 768px) 300px, 800px"
                  alt={website.title}
                  className="w-full h-full object-contain bg-gray-100"
                  loading="lazy"
                  decoding="async"
                />
              </div>
            </div>
          </Card>
          {website.verified ? (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center justify-center gap-2 cursor-help">
                    <h1 className="text-3xl font-bold text-center">{website.title}</h1>
                    <BadgeCheck className="h-6 w-6 text-[#c80613] bg-[#c80613]/10 rounded-full" />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>This website has been verified by its owners</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ) : (
            <h1 className="text-3xl font-bold text-center">{website.title}</h1>
          )}
          <a
            href={website.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex w-full items-center justify-center gap-2 bg-[#c80613] text-white px-6 py-3 rounded-lg hover:bg-[#c80613]/90 transition-colors"
          >
            Go to {website.title}
          </a>
        </div>

        <div className="md:col-span-2 space-y-4">
          {isAdmin && <div className="flex items-center gap-2 border-b pb-2">
              <Toggle size="sm" pressed={editor?.isActive("bold")} onPressedChange={() => editor?.chain().focus().toggleBold().run()}>
                <Bold className="h-4 w-4" />
              </Toggle>
              <Toggle size="sm" pressed={editor?.isActive("italic")} onPressedChange={() => editor?.chain().focus().toggleItalic().run()}>
                <Italic className="h-4 w-4" />
              </Toggle>
              <Toggle size="sm" pressed={editor?.isActive("underline")} onPressedChange={() => editor?.chain().focus().toggleUnderline().run()}>
                <UnderlineIcon className="h-4 w-4" />
              </Toggle>
              <Toggle size="sm" pressed={editor?.isActive("heading", {
            level: 1
          })} onPressedChange={() => editor?.chain().focus().toggleHeading({
            level: 1
          }).run()}>
                <Heading1 className="h-4 w-4" />
              </Toggle>
              <Toggle size="sm" pressed={editor?.isActive("heading", {
            level: 2
          })} onPressedChange={() => editor?.chain().focus().toggleHeading({
            level: 2
          }).run()}>
                <Heading2 className="h-4 w-4" />
              </Toggle>
              <Toggle size="sm" pressed={editor?.isActive("bulletList")} onPressedChange={() => editor?.chain().focus().toggleBulletList().run()}>
                <List className="h-4 w-4" />
              </Toggle>
            </div>}
          <Card className="overflow-hidden">
            <div className={`prose max-w-none p-6 ${isAdmin ? 'border rounded-lg' : ''} text-left`}>
              {editor?.isEditable ? <EditorContent editor={editor} /> : <div dangerouslySetInnerHTML={{
              __html: website.description
            }} />}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default WebsiteDetails;
