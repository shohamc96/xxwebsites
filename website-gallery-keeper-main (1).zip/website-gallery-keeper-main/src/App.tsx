
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { Toaster } from "@/components/ui/toaster";
import { Footer } from "@/components/Footer";
import Index from "@/pages/Index";
import Auth from "@/pages/Auth";
import NotFound from "@/pages/NotFound";
import WebsiteDetails from "@/pages/WebsiteDetails";
import Disclaimer from "@/pages/legal/Disclaimer";
import Section2257 from "@/pages/legal/Section2257";
import DMCA from "@/pages/legal/DMCA";
import PrivacyPolicy from "@/pages/legal/PrivacyPolicy";
import TermsOfService from "@/pages/legal/TermsOfService";
import RTA from "@/pages/legal/RTA";
import "./App.css";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/websites/:id" element={<WebsiteDetails />} />
          <Route path="/disclaimer" element={<Disclaimer />} />
          <Route path="/2257" element={<Section2257 />} />
          <Route path="/dmca" element={<DMCA />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms-of-service" element={<TermsOfService />} />
          <Route path="/rta" element={<RTA />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
        <Toaster />
      </Router>
    </AuthProvider>
  );
}

export default App;
