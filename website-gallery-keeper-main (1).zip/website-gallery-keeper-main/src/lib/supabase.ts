
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://hwcwzjwuvwziprdbqblx.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh3Y3d6and1dnd6aXByZGJxYmx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzk5NDc5MTksImV4cCI6MjA1NTUyMzkxOX0.0bGFV4T9KCwlfvVEvCe4qFb3zE5LCbCp-kyzUJApmVI';

export const supabase = createClient(supabaseUrl, supabaseKey);
